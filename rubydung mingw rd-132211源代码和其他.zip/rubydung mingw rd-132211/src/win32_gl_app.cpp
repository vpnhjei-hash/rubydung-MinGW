#include "win32_gl_app.h"

#include <GL/gl.h>
#include <GL/glu.h>

#include <cstring>

static const char* kWndClass = "RubyDungWin32GL";

Win32GLApp::Win32GLApp()
  : m_hwnd(NULL), m_hdc(NULL), m_glrc(NULL), m_w(0), m_h(0), m_fullscreen(false), m_cursorInit(false) {
  std::memset(&m_input, 0, sizeof(m_input));
  std::memset(m_lastErrorText, 0, sizeof(m_lastErrorText));
  m_input.mouseButtons[0] = false;
  m_input.mouseButtons[1] = false;
}

Win32GLApp::~Win32GLApp() { destroy(); }

static bool tryPixelFormat(HDC hdc, int colorBits, int depthBits) {
  PIXELFORMATDESCRIPTOR pfd;
  std::memset(&pfd, 0, sizeof(pfd));
  pfd.nSize = sizeof(pfd);
  pfd.nVersion = 1;
  pfd.dwFlags = PFD_DRAW_TO_WINDOW | PFD_SUPPORT_OPENGL | PFD_DOUBLEBUFFER;
  pfd.iPixelType = PFD_TYPE_RGBA;
  pfd.cColorBits = (BYTE)colorBits;
  pfd.cDepthBits = (BYTE)depthBits;
  pfd.cAlphaBits = 8;
  pfd.iLayerType = PFD_MAIN_PLANE;

  int pf = ChoosePixelFormat(hdc, &pfd);
  if (!pf) return false;
  if (!SetPixelFormat(hdc, pf, &pfd)) return false;
  return true;
}

static bool setupPixelFormatCompat(HDC hdc) {
  // Some old drivers/remote desktops fail with 24-bit depth. Try several fallbacks.
  if (tryPixelFormat(hdc, 32, 24)) return true;
  if (tryPixelFormat(hdc, 24, 24)) return true;
  if (tryPixelFormat(hdc, 32, 16)) return true;
  if (tryPixelFormat(hdc, 24, 16)) return true;
  return false;
}

void Win32GLApp::setLastError(const char* where) {
  DWORD e = GetLastError();
  char* msg = 0;
  FormatMessageA(FORMAT_MESSAGE_ALLOCATE_BUFFER | FORMAT_MESSAGE_FROM_SYSTEM | FORMAT_MESSAGE_IGNORE_INSERTS,
                 NULL, e, MAKELANGID(LANG_NEUTRAL, SUBLANG_DEFAULT), (LPSTR)&msg, 0, NULL);
  std::snprintf(m_lastErrorText, sizeof(m_lastErrorText) - 1,
                "%s failed. GetLastError=%lu %s", where, (unsigned long)e, msg ? msg : "");
  if (msg) LocalFree(msg);
}

bool Win32GLApp::create(const char* title, int w, int h, bool fullscreen) {
  std::memset(m_lastErrorText, 0, sizeof(m_lastErrorText));

  m_w = w;
  m_h = h;
  m_fullscreen = fullscreen;

  WNDCLASSEXA wc;
  std::memset(&wc, 0, sizeof(wc));
  wc.cbSize = sizeof(wc);
  wc.style = CS_OWNDC;
  wc.lpfnWndProc = &Win32GLApp::WndProcThunk;
  wc.hInstance = GetModuleHandleA(NULL);
  wc.hCursor = LoadCursor(NULL, IDC_ARROW);
  wc.lpszClassName = kWndClass;
  if (!RegisterClassExA(&wc)) {
    // It's ok if already registered.
    if (GetLastError() != ERROR_CLASS_ALREADY_EXISTS) {
      setLastError("RegisterClassExA");
      return false;
    }
  }

  DWORD style = WS_OVERLAPPEDWINDOW;
  RECT r = {0, 0, w, h};
  AdjustWindowRect(&r, style, FALSE);

  m_hwnd = CreateWindowExA(0, kWndClass, title, style | WS_CLIPSIBLINGS | WS_CLIPCHILDREN,
                          CW_USEDEFAULT, CW_USEDEFAULT,
                          r.right - r.left, r.bottom - r.top,
                          NULL, NULL, wc.hInstance, this);
  if (!m_hwnd) { setLastError("CreateWindowExA"); return false; }

  ShowWindow(m_hwnd, SW_SHOW);
  UpdateWindow(m_hwnd);

  m_hdc = GetDC(m_hwnd);
  if (!m_hdc) { setLastError("GetDC"); return false; }

  if (!setupPixelFormatCompat(m_hdc)) { setLastError("SetPixelFormat/ChoosePixelFormat"); return false; }

  m_glrc = wglCreateContext(m_hdc);
  if (!m_glrc) { setLastError("wglCreateContext"); return false; }
  if (!wglMakeCurrent(m_hdc, m_glrc)) { setLastError("wglMakeCurrent"); return false; }

  // capture mouse
  ShowCursor(FALSE);
  SetCapture(m_hwnd);
  RECT clip;
  GetClientRect(m_hwnd, &clip);
  POINT tl = {clip.left, clip.top};
  POINT br = {clip.right, clip.bottom};
  ClientToScreen(m_hwnd, &tl);
  ClientToScreen(m_hwnd, &br);
  clip.left = tl.x; clip.top = tl.y; clip.right = br.x; clip.bottom = br.y;
  ClipCursor(&clip);

  m_cursorInit = false;
  m_input.mouseEvents.clear();

  return true;
}

void Win32GLApp::destroy() {
  ClipCursor(NULL);
  if (m_hwnd) {
    ReleaseCapture();
    ShowCursor(TRUE);
  }

  if (m_glrc) {
    wglMakeCurrent(NULL, NULL);
    wglDeleteContext(m_glrc);
    m_glrc = NULL;
  }
  if (m_hdc && m_hwnd) {
    ReleaseDC(m_hwnd, m_hdc);
    m_hdc = NULL;
  }
  if (m_hwnd) {
    DestroyWindow(m_hwnd);
    m_hwnd = NULL;
  }
}

bool Win32GLApp::pumpEvents() {
  MSG msg;
  while (PeekMessageA(&msg, NULL, 0, 0, PM_REMOVE)) {
    if (msg.message == WM_QUIT) return false;
    TranslateMessage(&msg);
    DispatchMessageA(&msg);
  }
  return true;
}

void Win32GLApp::beginFrame() {
  // Do NOT clear mouseEvents here.
  // They are filled during pumpEvents() and must remain available for the game loop.
  updateKeyboard();
  updateMouseDelta();
}

void Win32GLApp::endFrame() {
  SwapBuffers(m_hdc);
}

void Win32GLApp::updateKeyboard() {
  // virtual keys
  m_input.keyEsc = (GetAsyncKeyState(VK_ESCAPE) & 0x8000) != 0;

  // Arrows or WASD
  m_input.keyUp = (GetAsyncKeyState(VK_UP) & 0x8000) != 0 || (GetAsyncKeyState('W') & 0x8000) != 0;
  m_input.keyDown = (GetAsyncKeyState(VK_DOWN) & 0x8000) != 0 || (GetAsyncKeyState('S') & 0x8000) != 0;
  m_input.keyLeft = (GetAsyncKeyState(VK_LEFT) & 0x8000) != 0 || (GetAsyncKeyState('A') & 0x8000) != 0;
  m_input.keyRight = (GetAsyncKeyState(VK_RIGHT) & 0x8000) != 0 || (GetAsyncKeyState('D') & 0x8000) != 0;
  m_input.keyJump = (GetAsyncKeyState(VK_SPACE) & 0x8000) != 0;
  m_input.keyReset = (GetAsyncKeyState('R') & 0x8000) != 0;
}

void Win32GLApp::updateMouseDelta() {
  // center cursor each frame and compute delta
  RECT rc;
  GetClientRect(m_hwnd, &rc);
  POINT center;
  center.x = (rc.right - rc.left) / 2;
  center.y = (rc.bottom - rc.top) / 2;
  ClientToScreen(m_hwnd, &center);

  POINT cur;
  GetCursorPos(&cur);

  if (!m_cursorInit) {
    m_lastCursor = cur;
    m_cursorInit = true;
  }

  m_input.mouseDX = cur.x - center.x;
  m_input.mouseDY = cur.y - center.y;

  SetCursorPos(center.x, center.y);
}

LRESULT CALLBACK Win32GLApp::WndProcThunk(HWND hWnd, UINT msg, WPARAM wParam, LPARAM lParam) {
  Win32GLApp* self = reinterpret_cast<Win32GLApp*>(GetWindowLongPtrA(hWnd, GWLP_USERDATA));
  if (msg == WM_NCCREATE) {
    CREATESTRUCTA* cs = reinterpret_cast<CREATESTRUCTA*>(lParam);
    self = reinterpret_cast<Win32GLApp*>(cs->lpCreateParams);
    SetWindowLongPtrA(hWnd, GWLP_USERDATA, reinterpret_cast<LONG_PTR>(self));
  }
  if (self) return self->wndProc(hWnd, msg, wParam, lParam);
  return DefWindowProcA(hWnd, msg, wParam, lParam);
}

LRESULT Win32GLApp::wndProc(HWND hWnd, UINT msg, WPARAM wParam, LPARAM lParam) {
  switch (msg) {
    case WM_CLOSE:
      PostQuitMessage(0);
      return 0;

    case WM_LBUTTONDOWN:
    case WM_LBUTTONUP: {
      bool down = (msg == WM_LBUTTONDOWN);
      m_input.mouseButtons[0] = down;
      MouseEvent ev; ev.button = 0; ev.down = down;
      m_input.mouseEvents.push_back(ev);
      return 0;
    }

    case WM_RBUTTONDOWN:
    case WM_RBUTTONUP: {
      bool down = (msg == WM_RBUTTONDOWN);
      m_input.mouseButtons[1] = down;
      MouseEvent ev; ev.button = 1; ev.down = down;
      m_input.mouseEvents.push_back(ev);
      return 0;
    }

    default:
      break;
  }
  // NOTE: lParam is not needed for our handled messages above, but pass through for correctness.
  return DefWindowProcA(hWnd, msg, wParam, lParam);
}

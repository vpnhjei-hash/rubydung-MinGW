#pragma once

#include <vector>
#include <string>

struct AABB {
  float x0, y0, z0;
  float x1, y1, z1;
  float epsilon;

  AABB() : x0(0), y0(0), z0(0), x1(0), y1(0), z1(0), epsilon(0.0f) {}
  AABB(float _x0, float _y0, float _z0, float _x1, float _y1, float _z1)
    : x0(_x0), y0(_y0), z0(_z0), x1(_x1), y1(_y1), z1(_z1), epsilon(0.0f) {}

  AABB expand(float xa, float ya, float za) const;
  AABB grow(float xa, float ya, float za) const;

  float clipXCollide(const AABB& c, float xa) const;
  float clipYCollide(const AABB& c, float ya) const;
  float clipZCollide(const AABB& c, float za) const;

  bool intersects(const AABB& c) const;
  void move(float xa, float ya, float za);
};

struct HitResult {
  int x, y, z;
  int t;
  int f;
  HitResult() : x(0), y(0), z(0), t(0), f(0) {}
  HitResult(int _x, int _y, int _z, int _t, int _f) : x(_x), y(_y), z(_z), t(_t), f(_f) {}
};

class Timer {
public:
  Timer(float ticksPerSecond);
  void advanceTime();

  int ticks;
  float a;
  float timeScale;
  float fps;

private:
  static const long long NS_PER_SECOND = 1000000000LL;
  float ticksPerSecond;
  long long lastTime;
  float passedTime;

  static long long nanoTime();
};

class LevelListener {
public:
  virtual ~LevelListener() {}
  virtual void tileChanged(int x, int y, int z) = 0;
  virtual void lightColumnChanged(int x, int z, int y0, int y1) = 0;
  virtual void allChanged() = 0;
};

class Level {
public:
  const int width;
  const int height;
  const int depth;

  Level(int w, int h, int d);
  void load();
  void save();

  void addListener(LevelListener* l);
  void removeListener(LevelListener* l);

  bool isTile(int x, int y, int z) const;
  bool isSolidTile(int x, int y, int z) const;
  bool isLightBlocker(int x, int y, int z) const;

  std::vector<AABB> getCubes(const AABB& aabb) const;
  float getBrightness(int x, int y, int z) const;

  void setTile(int x, int y, int z, int type);

private:
  std::vector<unsigned char> blocks;
  std::vector<int> lightDepths;
  std::vector<LevelListener*> listeners;

  void calcLightDepths(int x0, int y0, int x1, int y1);
  int index(int x, int y, int z) const { return (y * height + z) * width + x; }
};

class Tesselator {
public:
  Tesselator();
  void init();
  void tex(float u, float v);
  void color(float r, float g, float b);
  void vertex(float x, float y, float z);
  void flush();

private:
  enum { MAX_VERTICES = 100000 };
  std::vector<float> vtx;   // 3 * n
  std::vector<float> texc;  // 2 * n
  std::vector<float> col;   // 3 * n
  int vertices;
  float u, v;
  float r, g, b;
  bool hasColor;
  bool hasTexture;

  void clear();
};

class Tile {
public:
  static Tile rock;
  static Tile grass;

  void render(Tesselator& t, const Level& level, int layer, int x, int y, int z) const;
  void renderFace(Tesselator& t, int x, int y, int z, int face) const;

private:
  int tex;
  explicit Tile(int t);
};

class Textures {
public:
  static int loadTexture(const std::string& filename, int mode);
  static void bind(int id);

private:
  static int lastId;
};

class Chunk {
public:
  AABB aabb;
  Level& level;
  int x0, y0, z0;
  int x1, y1, z1;

  Chunk(Level& level, int x0, int y0, int z0, int x1, int y1, int z1);
  void render(int layer);
  void setDirty();

  static int rebuiltThisFrame;
  static int updates;

private:
  bool dirty;
  int lists;

  static int texture;
  static Tesselator t;

  void rebuild(int layer);
};

class Player {
public:
  Player(Level& level);

  float xo, yo, zo;
  float x, y, z;
  float xd, yd, zd;
  float yRot, xRot;
  AABB bb;
  bool onGround;

  void turn(float xo, float yo);
  void tick(bool keyReset, bool keyUp, bool keyDown, bool keyLeft, bool keyRight, bool keyJump);

private:
  Level& level;
  void resetPos();
  void setPos(float x, float y, float z);
  void move(float xa, float ya, float za);
  void moveRelative(float xa, float za, float speed);
};

class Frustum {
public:
  static Frustum& getFrustum();
  bool cubeInFrustum(const AABB& aabb) const;

private:
  float frustum[6][4];
  Frustum();
  void calculateFrustum();
};

class LevelRenderer : public LevelListener {
public:
  LevelRenderer(Level& level);
  ~LevelRenderer();
  void render(Player& player, int layer);
  void pick(Player& player);
  void renderHit(const HitResult& h);

  virtual void tileChanged(int x, int y, int z);
  virtual void lightColumnChanged(int x, int z, int y0, int y1);
  virtual void allChanged();

private:
  enum { CHUNK_SIZE = 16 };
  Level& level;
  std::vector<Chunk*> chunks;
  int xChunks, yChunks, zChunks;
  Tesselator t;

  void setDirty(int x0, int y0, int z0, int x1, int y1, int z1);
};

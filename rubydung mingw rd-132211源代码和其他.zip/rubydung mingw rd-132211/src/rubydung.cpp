#include "rubydung.h"

#include <cmath>
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <fstream>

#include <windows.h>

#include <GL/gl.h>
#include <GL/glu.h>

#include "../third_party/lodepng.h"
#include "../third_party/miniz.h"

// ---------------- AABB ----------------
AABB AABB::expand(float xa, float ya, float za) const {
  float _x0 = x0, _y0 = y0, _z0 = z0;
  float _x1 = x1, _y1 = y1, _z1 = z1;
  if (xa < 0.0f) _x0 += xa;
  if (xa > 0.0f) _x1 += xa;
  if (ya < 0.0f) _y0 += ya;
  if (ya > 0.0f) _y1 += ya;
  if (za < 0.0f) _z0 += za;
  if (za > 0.0f) _z1 += za;
  return AABB(_x0, _y0, _z0, _x1, _y1, _z1);
}

AABB AABB::grow(float xa, float ya, float za) const {
  return AABB(x0 - xa, y0 - ya, z0 - za, x1 + xa, y1 + ya, z1 + za);
}

float AABB::clipXCollide(const AABB& c, float xa) const {
  if (c.y1 <= y0 || c.y0 >= y1) return xa;
  if (c.z1 <= z0 || c.z0 >= z1) return xa;
  float maxv;
  if (xa > 0.0f && c.x1 <= x0 && (maxv = x0 - c.x1 - epsilon) < xa) xa = maxv;
  if (xa < 0.0f && c.x0 >= x1 && (maxv = x1 - c.x0 + epsilon) > xa) xa = maxv;
  return xa;
}

float AABB::clipYCollide(const AABB& c, float ya) const {
  if (c.x1 <= x0 || c.x0 >= x1) return ya;
  if (c.z1 <= z0 || c.z0 >= z1) return ya;
  float maxv;
  if (ya > 0.0f && c.y1 <= y0 && (maxv = y0 - c.y1 - epsilon) < ya) ya = maxv;
  if (ya < 0.0f && c.y0 >= y1 && (maxv = y1 - c.y0 + epsilon) > ya) ya = maxv;
  return ya;
}

float AABB::clipZCollide(const AABB& c, float za) const {
  if (c.x1 <= x0 || c.x0 >= x1) return za;
  if (c.y1 <= y0 || c.y0 >= y1) return za;
  float maxv;
  if (za > 0.0f && c.z1 <= z0 && (maxv = z0 - c.z1 - epsilon) < za) za = maxv;
  if (za < 0.0f && c.z0 >= z1 && (maxv = z1 - c.z0 + epsilon) > za) za = maxv;
  return za;
}

bool AABB::intersects(const AABB& c) const {
  if (c.x1 <= x0 || c.x0 >= x1) return false;
  if (c.y1 <= y0 || c.y0 >= y1) return false;
  if (c.z1 <= z0 || c.z0 >= z1) return false;
  return true;
}

void AABB::move(float xa, float ya, float za) {
  x0 += xa; y0 += ya; z0 += za;
  x1 += xa; y1 += ya; z1 += za;
}

// ---------------- Timer ----------------
static long long qpcToNs(LARGE_INTEGER c) {
  static LARGE_INTEGER freq = {0};
  if (!freq.QuadPart) QueryPerformanceFrequency(&freq);
  return (long long)((c.QuadPart * 1000000000LL) / freq.QuadPart);
}

long long Timer::nanoTime() {
  LARGE_INTEGER c;
  QueryPerformanceCounter(&c);
  return qpcToNs(c);
}

Timer::Timer(float tps)
  : ticks(0), a(0.0f), timeScale(1.0f), fps(0.0f), ticksPerSecond(tps), lastTime(nanoTime()), passedTime(0.0f) {
}

void Timer::advanceTime() {
  long long now = nanoTime();
  long long passedNs = now - lastTime;
  lastTime = now;
  if (passedNs < 0) passedNs = 0;
  if (passedNs > 1000000000LL) passedNs = 1000000000LL;
  fps = (passedNs > 0) ? (float)(1000000000LL / passedNs) : 0.0f;
  passedTime += (float)passedNs * timeScale * ticksPerSecond / 1.0e9f;
  ticks = (int)passedTime;
  if (ticks > 100) ticks = 100;
  passedTime -= (float)ticks;
  a = passedTime;
}

// ---------------- Gzip helpers (manual header/footer + miniz raw deflate) ----------------
static bool readFileAll(const char* path, std::vector<unsigned char>& out) {
  std::ifstream f(path, std::ios::in | std::ios::binary);
  if (!f) return false;
  f.seekg(0, std::ios::end);
  std::streamoff sz = f.tellg();
  f.seekg(0, std::ios::beg);
  out.resize((size_t)sz);
  if (sz > 0) f.read((char*)&out[0], sz);
  return true;
}

static bool writeFileAll(const char* path, const std::vector<unsigned char>& data) {
  std::ofstream f(path, std::ios::out | std::ios::binary);
  if (!f) return false;
  if (!data.empty()) f.write((const char*)&data[0], (std::streamsize)data.size());
  return true;
}

static bool gzipDecompress(const std::vector<unsigned char>& gz, std::vector<unsigned char>& out) {
  if (gz.size() < 18) return false;
  if (gz[0] != 0x1f || gz[1] != 0x8b || gz[2] != 8) return false; // gzip + deflate

  size_t p = 10;
  unsigned char flg = gz[3];
  // skip extra fields
  if (flg & 0x04) { // FEXTRA
    if (p + 2 > gz.size()) return false;
    unsigned xlen = gz[p] | (gz[p+1] << 8);
    p += 2 + xlen;
  }
  if (flg & 0x08) { // FNAME
    while (p < gz.size() && gz[p] != 0) ++p;
    ++p;
  }
  if (flg & 0x10) { // FCOMMENT
    while (p < gz.size() && gz[p] != 0) ++p;
    ++p;
  }
  if (flg & 0x02) { // FHCRC
    p += 2;
  }
  if (p >= gz.size() || gz.size() < p + 8) return false;

  // footer: last 8 bytes
  size_t compEnd = gz.size() - 8;
  if (compEnd <= p) return false;
  const unsigned char* comp = &gz[p];
  size_t compSize = compEnd - p;

  // ISIZE (mod 2^32)
  unsigned isize = (unsigned)gz[gz.size()-4] | ((unsigned)gz[gz.size()-3] << 8) | ((unsigned)gz[gz.size()-2] << 16) | ((unsigned)gz[gz.size()-1] << 24);

  out.resize(isize);
  size_t actual = tinfl_decompress_mem_to_mem(&out[0], out.size(), comp, compSize, 0);
  return actual == out.size();
}

static bool gzipCompress(const unsigned char* data, size_t size, std::vector<unsigned char>& out) {
  // deflate raw
  size_t compSize = 0;
  void* comp = tdefl_compress_mem_to_heap(data, size, &compSize, TDEFL_DEFAULT_MAX_PROBES);
  if (!comp) return false;

  out.clear();
  out.reserve(10 + compSize + 8);

  // gzip header
  out.push_back(0x1f);
  out.push_back(0x8b);
  out.push_back(8);      // deflate
  out.push_back(0);      // flags
  out.push_back(0); out.push_back(0); out.push_back(0); out.push_back(0); // mtime
  out.push_back(0);      // xflags
  out.push_back(255);    // os=unknown

  // body
  unsigned char* c = (unsigned char*)comp;
  out.insert(out.end(), c, c + compSize);

  // footer: CRC32 + ISIZE
  mz_ulong crc = mz_crc32(MZ_CRC32_INIT, data, size);
  out.push_back((unsigned char)(crc & 0xFF));
  out.push_back((unsigned char)((crc >> 8) & 0xFF));
  out.push_back((unsigned char)((crc >> 16) & 0xFF));
  out.push_back((unsigned char)((crc >> 24) & 0xFF));

  unsigned isize = (unsigned)(size & 0xFFFFFFFFu);
  out.push_back((unsigned char)(isize & 0xFF));
  out.push_back((unsigned char)((isize >> 8) & 0xFF));
  out.push_back((unsigned char)((isize >> 16) & 0xFF));
  out.push_back((unsigned char)((isize >> 24) & 0xFF));

  mz_free(comp);
  return true;
}

// ---------------- Level ----------------
Level::Level(int w, int h, int d)
  : width(w), height(h), depth(d), blocks(w*h*d), lightDepths(w*h), listeners() {

  for (int x = 0; x < w; ++x) {
    for (int y = 0; y < d; ++y) {
      for (int z = 0; z < h; ++z) {
        int i = index(x, y, z);
        blocks[i] = (unsigned char)((y <= d * 2 / 3) ? 1 : 0);
      }
    }
  }

  calcLightDepths(0, 0, w, h);
  load();
}

void Level::load() {
  std::vector<unsigned char> gz;
  if (!readFileAll("level.dat", gz)) return;

  std::vector<unsigned char> raw;
  if (!gzipDecompress(gz, raw)) {
    // fallback: try raw file without gzip
    raw = gz;
  }
  if (raw.size() != blocks.size()) return;
  blocks = raw;
  calcLightDepths(0, 0, width, height);
  for (size_t i = 0; i < listeners.size(); ++i) listeners[i]->allChanged();
}

void Level::save() {
  std::vector<unsigned char> gz;
  if (gzipCompress(&blocks[0], blocks.size(), gz)) {
    writeFileAll("level.dat", gz);
  } else {
    // fallback
    writeFileAll("level.dat", blocks);
  }
}

void Level::addListener(LevelListener* l) { listeners.push_back(l); }

void Level::removeListener(LevelListener* l) {
  for (size_t i = 0; i < listeners.size(); ++i) {
    if (listeners[i] == l) { listeners.erase(listeners.begin() + (long)i); break; }
  }
}

void Level::calcLightDepths(int x0, int y0, int x1, int y1) {
  for (int x = x0; x < x0 + x1; ++x) {
    for (int z = y0; z < y0 + y1; ++z) {
      int oldDepth = lightDepths[x + z * width];
      int y = depth - 1;
      while (y > 0 && !isLightBlocker(x, y, z)) --y;
      lightDepths[x + z * width] = y;
      if (oldDepth != y) {
        int yl0 = oldDepth < y ? oldDepth : y;
        int yl1 = oldDepth > y ? oldDepth : y;
        for (size_t i = 0; i < listeners.size(); ++i) listeners[i]->lightColumnChanged(x, z, yl0, yl1);
      }
    }
  }
}

bool Level::isTile(int x, int y, int z) const {
  if (x < 0 || y < 0 || z < 0 || x >= width || y >= depth || z >= height) return false;
  return blocks[index(x, y, z)] == 1;
}

bool Level::isSolidTile(int x, int y, int z) const { return isTile(x, y, z); }
bool Level::isLightBlocker(int x, int y, int z) const { return isSolidTile(x, y, z); }

std::vector<AABB> Level::getCubes(const AABB& aabb) const {
  std::vector<AABB> aabbs;
  int x0 = (int)aabb.x0;
  int x1 = (int)(aabb.x1 + 1.0f);
  int y0 = (int)aabb.y0;
  int y1 = (int)(aabb.y1 + 1.0f);
  int z0 = (int)aabb.z0;
  int z1 = (int)(aabb.z1 + 1.0f);

  if (x0 < 0) x0 = 0;
  if (y0 < 0) y0 = 0;
  if (z0 < 0) z0 = 0;
  if (x1 > width) x1 = width;
  if (y1 > depth) y1 = depth;
  if (z1 > height) z1 = height;

  for (int x = x0; x < x1; ++x) {
    for (int y = y0; y < y1; ++y) {
      for (int z = z0; z < z1; ++z) {
        if (isSolidTile(x, y, z)) aabbs.push_back(AABB((float)x, (float)y, (float)z, (float)(x+1), (float)(y+1), (float)(z+1)));
      }
    }
  }
  return aabbs;
}

float Level::getBrightness(int x, int y, int z) const {
  float dark = 0.8f;
  float light = 1.0f;
  if (x < 0 || y < 0 || z < 0 || x >= width || y >= depth || z >= height) return light;
  if (y < lightDepths[x + z * width]) return dark;
  return light;
}

void Level::setTile(int x, int y, int z, int type) {
  if (x < 0 || y < 0 || z < 0 || x >= width || y >= depth || z >= height) return;
  blocks[index(x, y, z)] = (unsigned char)type;
  calcLightDepths(x, z, 1, 1);
  for (size_t i = 0; i < listeners.size(); ++i) listeners[i]->tileChanged(x, y, z);
}

// ---------------- Tesselator ----------------
Tesselator::Tesselator() : vertices(0), u(0), v(0), r(1), g(1), b(1), hasColor(false), hasTexture(false) {
  vtx.reserve(MAX_VERTICES * 3);
  texc.reserve(MAX_VERTICES * 2);
  col.reserve(MAX_VERTICES * 3);
}

void Tesselator::clear() {
  vertices = 0;
  vtx.clear();
  texc.clear();
  col.clear();
}

void Tesselator::init() {
  clear();
  hasColor = false;
  hasTexture = false;
}

void Tesselator::tex(float _u, float _v) { hasTexture = true; u = _u; v = _v; }
void Tesselator::color(float _r, float _g, float _b) { hasColor = true; r = _r; g = _g; b = _b; }

void Tesselator::vertex(float x, float y, float z) {
  vtx.push_back(x);
  vtx.push_back(y);
  vtx.push_back(z);
  if (hasTexture) {
    texc.push_back(u);
    texc.push_back(v);
  }
  if (hasColor) {
    col.push_back(r);
    col.push_back(g);
    col.push_back(b);
  }

  ++vertices;
  if (vertices == MAX_VERTICES) flush();
}

void Tesselator::flush() {
  if (vertices <= 0) { clear(); return; }

  glVertexPointer(3, GL_FLOAT, 0, &vtx[0]);
  if (hasTexture) glTexCoordPointer(2, GL_FLOAT, 0, &texc[0]);
  if (hasColor) glColorPointer(3, GL_FLOAT, 0, &col[0]);

  glEnableClientState(GL_VERTEX_ARRAY);
  if (hasTexture) glEnableClientState(GL_TEXTURE_COORD_ARRAY);
  if (hasColor) glEnableClientState(GL_COLOR_ARRAY);

  glDrawArrays(GL_QUADS, 0, vertices);

  glDisableClientState(GL_VERTEX_ARRAY);
  if (hasTexture) glDisableClientState(GL_TEXTURE_COORD_ARRAY);
  if (hasColor) glDisableClientState(GL_COLOR_ARRAY);

  clear();
}

// ---------------- Tile ----------------
Tile Tile::rock(0);
Tile Tile::grass(1);

Tile::Tile(int t) : tex(t) {}

void Tile::render(Tesselator& t, const Level& level, int layer, int x, int y, int z) const {
  float br;
  float u0 = (float)tex / 16.0f;
  float u1 = u0 + 0.0624375f;
  float v0 = 0.0f;
  float v1 = v0 + 0.0624375f;
  float c1 = 1.0f;
  float c2 = 0.8f;
  float c3 = 0.6f;
  float x0 = (float)x + 0.0f;
  float x1 = (float)x + 1.0f;
  float y0 = (float)y + 0.0f;
  float y1 = (float)y + 1.0f;
  float z0 = (float)z + 0.0f;
  float z1 = (float)z + 1.0f;

  if (!level.isSolidTile(x, y - 1, z) && ((br = level.getBrightness(x, y - 1, z) * c1) == c1) ^ (layer == 1)) {
    t.color(br, br, br);
    t.tex(u0, v1); t.vertex(x0, y0, z1);
    t.tex(u0, v0); t.vertex(x0, y0, z0);
    t.tex(u1, v0); t.vertex(x1, y0, z0);
    t.tex(u1, v1); t.vertex(x1, y0, z1);
  }
  if (!level.isSolidTile(x, y + 1, z) && ((br = level.getBrightness(x, y, z) * c1) == c1) ^ (layer == 1)) {
    t.color(br, br, br);
    t.tex(u1, v1); t.vertex(x1, y1, z1);
    t.tex(u1, v0); t.vertex(x1, y1, z0);
    t.tex(u0, v0); t.vertex(x0, y1, z0);
    t.tex(u0, v1); t.vertex(x0, y1, z1);
  }
  if (!level.isSolidTile(x, y, z - 1) && ((br = level.getBrightness(x, y, z - 1) * c2) == c2) ^ (layer == 1)) {
    t.color(br, br, br);
    t.tex(u1, v0); t.vertex(x0, y1, z0);
    t.tex(u0, v0); t.vertex(x1, y1, z0);
    t.tex(u0, v1); t.vertex(x1, y0, z0);
    t.tex(u1, v1); t.vertex(x0, y0, z0);
  }
  if (!level.isSolidTile(x, y, z + 1) && ((br = level.getBrightness(x, y, z + 1) * c2) == c2) ^ (layer == 1)) {
    t.color(br, br, br);
    t.tex(u0, v0); t.vertex(x0, y1, z1);
    t.tex(u0, v1); t.vertex(x0, y0, z1);
    t.tex(u1, v1); t.vertex(x1, y0, z1);
    t.tex(u1, v0); t.vertex(x1, y1, z1);
  }
  if (!level.isSolidTile(x - 1, y, z) && ((br = level.getBrightness(x - 1, y, z) * c3) == c3) ^ (layer == 1)) {
    t.color(br, br, br);
    t.tex(u1, v0); t.vertex(x0, y1, z1);
    t.tex(u0, v0); t.vertex(x0, y1, z0);
    t.tex(u0, v1); t.vertex(x0, y0, z0);
    t.tex(u1, v1); t.vertex(x0, y0, z1);
  }
  if (!level.isSolidTile(x + 1, y, z) && ((br = level.getBrightness(x + 1, y, z) * c3) == c3) ^ (layer == 1)) {
    t.color(br, br, br);
    t.tex(u0, v1); t.vertex(x1, y0, z1);
    t.tex(u1, v1); t.vertex(x1, y0, z0);
    t.tex(u1, v0); t.vertex(x1, y1, z0);
    t.tex(u0, v0); t.vertex(x1, y1, z1);
  }
}

void Tile::renderFace(Tesselator& t, int x, int y, int z, int face) const {
  float x0 = (float)x + 0.0f;
  float x1 = (float)x + 1.0f;
  float y0 = (float)y + 0.0f;
  float y1 = (float)y + 1.0f;
  float z0 = (float)z + 0.0f;
  float z1 = (float)z + 1.0f;
  if (face == 0) { t.vertex(x0, y0, z1); t.vertex(x0, y0, z0); t.vertex(x1, y0, z0); t.vertex(x1, y0, z1); }
  if (face == 1) { t.vertex(x1, y1, z1); t.vertex(x1, y1, z0); t.vertex(x0, y1, z0); t.vertex(x0, y1, z1); }
  if (face == 2) { t.vertex(x0, y1, z0); t.vertex(x1, y1, z0); t.vertex(x1, y0, z0); t.vertex(x0, y0, z0); }
  if (face == 3) { t.vertex(x0, y1, z1); t.vertex(x0, y0, z1); t.vertex(x1, y0, z1); t.vertex(x1, y1, z1); }
  if (face == 4) { t.vertex(x0, y1, z1); t.vertex(x0, y1, z0); t.vertex(x0, y0, z0); t.vertex(x0, y0, z1); }
  if (face == 5) { t.vertex(x1, y0, z1); t.vertex(x1, y0, z0); t.vertex(x1, y1, z0); t.vertex(x1, y1, z1); }
}

// ---------------- Textures ----------------
int Textures::lastId = -9999999;

int Textures::loadTexture(const std::string& filename, int mode) {
  // decode png (RGBA)
  std::vector<unsigned char> image;
  unsigned w = 0, h = 0;
  unsigned err = lodepng::decode(image, w, h, filename);
  if (err) {
    std::fprintf(stderr, "Failed to load %s: %u %s\n", filename.c_str(), err, lodepng_error_text(err));
    return 0;
  }

  GLuint id = 0;
  glGenTextures(1, &id);
  bind((int)id);
  glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, mode);
  glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, mode);

  // Build mipmaps (same as Java GLU.gluBuild2DMipmaps)
  gluBuild2DMipmaps(GL_TEXTURE_2D, GL_RGBA, (GLsizei)w, (GLsizei)h, GL_RGBA, GL_UNSIGNED_BYTE, &image[0]);
  return (int)id;
}

void Textures::bind(int id) {
  if (id != lastId) {
    glBindTexture(GL_TEXTURE_2D, (GLuint)id);
    lastId = id;
  }
}

// ---------------- Chunk ----------------
int Chunk::rebuiltThisFrame = 0;
int Chunk::updates = 0;
int Chunk::texture = 0;
Tesselator Chunk::t;

Chunk::Chunk(Level& lvl, int _x0, int _y0, int _z0, int _x1, int _y1, int _z1)
  : aabb((float)_x0, (float)_y0, (float)_z0, (float)_x1, (float)_y1, (float)_z1),
    level(lvl), x0(_x0), y0(_y0), z0(_z0), x1(_x1), y1(_y1), z1(_z1), dirty(true), lists(-1) {

  if (texture == 0) {
    texture = Textures::loadTexture("terrain.png", GL_NEAREST);
  }
  lists = glGenLists(2);
}

void Chunk::rebuild(int layer) {
  if (rebuiltThisFrame == 2) return;
  dirty = false;
  ++updates;
  ++rebuiltThisFrame;

  glNewList(lists + layer, GL_COMPILE);
  glEnable(GL_TEXTURE_2D);
  glBindTexture(GL_TEXTURE_2D, (GLuint)texture);
  t.init();

  for (int x = x0; x < x1; ++x) {
    for (int y = y0; y < y1; ++y) {
      for (int z = z0; z < z1; ++z) {
        if (level.isTile(x, y, z)) {
          bool tex = (y != level.depth * 2 / 3);
          if (!tex) Tile::rock.render(t, level, layer, x, y, z);
          else Tile::grass.render(t, level, layer, x, y, z);
        }
      }
    }
  }

  t.flush();
  glDisable(GL_TEXTURE_2D);
  glEndList();
}

void Chunk::render(int layer) {
  if (dirty) {
    rebuild(0);
    rebuild(1);
  }
  glCallList(lists + layer);
}

void Chunk::setDirty() { dirty = true; }

// ---------------- Player ----------------
Player::Player(Level& lvl)
  : xo(0), yo(0), zo(0), x(0), y(0), z(0), xd(0), yd(0), zd(0), yRot(0), xRot(0), bb(), onGround(false), level(lvl) {
  resetPos();
}

void Player::resetPos() {
  float rx = (float)std::rand() / (float)RAND_MAX;
  float rz = (float)std::rand() / (float)RAND_MAX;
  float px = rx * (float)level.width;
  float py = (float)level.depth + 10.0f;
  float pz = rz * (float)level.height;
  setPos(px, py, pz);
}

void Player::setPos(float _x, float _y, float _z) {
  x = _x; y = _y; z = _z;
  float w = 0.3f;
  float h = 0.9f;
  bb = AABB(x - w, y - h, z - w, x + w, y + h, z + w);
}

void Player::turn(float xo_, float yo_) {
  yRot = (float)((double)yRot + (double)xo_ * 0.15);
  xRot = (float)((double)xRot - (double)yo_ * 0.15);
  if (xRot < -90.0f) xRot = -90.0f;
  if (xRot > 90.0f) xRot = 90.0f;
}

void Player::tick(bool keyReset, bool keyUp, bool keyDown, bool keyLeft, bool keyRight, bool keyJump) {
  xo = x; yo = y; zo = z;
  float xa = 0.0f;
  float ya = 0.0f;

  if (keyReset) resetPos();
  if (keyUp) ya -= 1.0f;
  if (keyDown) ya += 1.0f;
  if (keyLeft) xa -= 1.0f;
  if (keyRight) xa += 1.0f;
  if (keyJump && onGround) yd = 0.12f;

  moveRelative(xa, ya, onGround ? 0.02f : 0.005f);
  yd = (float)((double)yd - 0.005);
  move(xd, yd, zd);

  xd *= 0.91f;
  yd *= 0.98f;
  zd *= 0.91f;
  if (onGround) { xd *= 0.8f; zd *= 0.8f; }
}

void Player::move(float xa, float ya, float za) {
  float xaOrg = xa;
  float yaOrg = ya;
  float zaOrg = za;

  std::vector<AABB> aabbs = level.getCubes(bb.expand(xa, ya, za));

  for (size_t i = 0; i < aabbs.size(); ++i) ya = aabbs[i].clipYCollide(bb, ya);
  bb.move(0.0f, ya, 0.0f);

  for (size_t i = 0; i < aabbs.size(); ++i) xa = aabbs[i].clipXCollide(bb, xa);
  bb.move(xa, 0.0f, 0.0f);

  for (size_t i = 0; i < aabbs.size(); ++i) za = aabbs[i].clipZCollide(bb, za);
  bb.move(0.0f, 0.0f, za);

  onGround = (yaOrg != ya) && (yaOrg < 0.0f);
  if (xaOrg != xa) xd = 0.0f;
  if (yaOrg != ya) yd = 0.0f;
  if (zaOrg != za) zd = 0.0f;

  x = (bb.x0 + bb.x1) / 2.0f;
  y = bb.y0 + 1.62f;
  z = (bb.z0 + bb.z1) / 2.0f;
}

void Player::moveRelative(float xa, float za, float speed) {
  float dist = xa * xa + za * za;
  if (dist < 0.01f) return;
  dist = speed / (float)std::sqrt(dist);
  float sinv = (float)std::sin((double)yRot * 3.141592653589793 / 180.0);
  float cosv = (float)std::cos((double)yRot * 3.141592653589793 / 180.0);

  xa *= dist;
  za *= dist;
  xd += xa * cosv - za * sinv;
  zd += za * cosv + xa * sinv;
}

// ---------------- Frustum ----------------
Frustum::Frustum() {
  std::memset(frustum, 0, sizeof(frustum));
}

Frustum& Frustum::getFrustum() {
  static Frustum inst;
  inst.calculateFrustum();
  return inst;
}

static void normalizePlane(float p[4]) {
  float mag = (float)std::sqrt(p[0]*p[0] + p[1]*p[1] + p[2]*p[2]);
  if (mag == 0.0f) return;
  p[0] /= mag; p[1] /= mag; p[2] /= mag; p[3] /= mag;
}

void Frustum::calculateFrustum() {
  float proj[16];
  float modl[16];
  float clip[16];

  glGetFloatv(GL_PROJECTION_MATRIX, proj);
  glGetFloatv(GL_MODELVIEW_MATRIX, modl);

  // clip = modl * proj
  clip[0]  = modl[0] * proj[0]  + modl[1] * proj[4]  + modl[2] * proj[8]  + modl[3] * proj[12];
  clip[1]  = modl[0] * proj[1]  + modl[1] * proj[5]  + modl[2] * proj[9]  + modl[3] * proj[13];
  clip[2]  = modl[0] * proj[2]  + modl[1] * proj[6]  + modl[2] * proj[10] + modl[3] * proj[14];
  clip[3]  = modl[0] * proj[3]  + modl[1] * proj[7]  + modl[2] * proj[11] + modl[3] * proj[15];

  clip[4]  = modl[4] * proj[0]  + modl[5] * proj[4]  + modl[6] * proj[8]  + modl[7] * proj[12];
  clip[5]  = modl[4] * proj[1]  + modl[5] * proj[5]  + modl[6] * proj[9]  + modl[7] * proj[13];
  clip[6]  = modl[4] * proj[2]  + modl[5] * proj[6]  + modl[6] * proj[10] + modl[7] * proj[14];
  clip[7]  = modl[4] * proj[3]  + modl[5] * proj[7]  + modl[6] * proj[11] + modl[7] * proj[15];

  clip[8]  = modl[8] * proj[0]  + modl[9] * proj[4]  + modl[10]* proj[8]  + modl[11]* proj[12];
  clip[9]  = modl[8] * proj[1]  + modl[9] * proj[5]  + modl[10]* proj[9]  + modl[11]* proj[13];
  clip[10] = modl[8] * proj[2]  + modl[9] * proj[6]  + modl[10]* proj[10] + modl[11]* proj[14];
  clip[11] = modl[8] * proj[3]  + modl[9] * proj[7]  + modl[10]* proj[11] + modl[11]* proj[15];

  clip[12] = modl[12]* proj[0]  + modl[13]* proj[4]  + modl[14]* proj[8]  + modl[15]* proj[12];
  clip[13] = modl[12]* proj[1]  + modl[13]* proj[5]  + modl[14]* proj[9]  + modl[15]* proj[13];
  clip[14] = modl[12]* proj[2]  + modl[13]* proj[6]  + modl[14]* proj[10] + modl[15]* proj[14];
  clip[15] = modl[12]* proj[3]  + modl[13]* proj[7]  + modl[14]* proj[11] + modl[15]* proj[15];

  // Right plane
  frustum[0][0] = clip[3] - clip[0];
  frustum[0][1] = clip[7] - clip[4];
  frustum[0][2] = clip[11]- clip[8];
  frustum[0][3] = clip[15]- clip[12];
  normalizePlane(frustum[0]);

  // Left plane
  frustum[1][0] = clip[3] + clip[0];
  frustum[1][1] = clip[7] + clip[4];
  frustum[1][2] = clip[11]+ clip[8];
  frustum[1][3] = clip[15]+ clip[12];
  normalizePlane(frustum[1]);

  // Bottom
  frustum[2][0] = clip[3] + clip[1];
  frustum[2][1] = clip[7] + clip[5];
  frustum[2][2] = clip[11]+ clip[9];
  frustum[2][3] = clip[15]+ clip[13];
  normalizePlane(frustum[2]);

  // Top
  frustum[3][0] = clip[3] - clip[1];
  frustum[3][1] = clip[7] - clip[5];
  frustum[3][2] = clip[11]- clip[9];
  frustum[3][3] = clip[15]- clip[13];
  normalizePlane(frustum[3]);

  // Far
  frustum[4][0] = clip[3] - clip[2];
  frustum[4][1] = clip[7] - clip[6];
  frustum[4][2] = clip[11]- clip[10];
  frustum[4][3] = clip[15]- clip[14];
  normalizePlane(frustum[4]);

  // Near
  frustum[5][0] = clip[3] + clip[2];
  frustum[5][1] = clip[7] + clip[6];
  frustum[5][2] = clip[11]+ clip[10];
  frustum[5][3] = clip[15]+ clip[14];
  normalizePlane(frustum[5]);
}

static inline bool pointInPlane(const float p[4], float x, float y, float z) {
  return p[0]*x + p[1]*y + p[2]*z + p[3] > 0.0f;
}

bool Frustum::cubeInFrustum(const AABB& aabb) const {
  for (int i = 0; i < 6; ++i) {
    const float* p = frustum[i];
    if ( pointInPlane(p, aabb.x0, aabb.y0, aabb.z0) ) continue;
    if ( pointInPlane(p, aabb.x1, aabb.y0, aabb.z0) ) continue;
    if ( pointInPlane(p, aabb.x0, aabb.y1, aabb.z0) ) continue;
    if ( pointInPlane(p, aabb.x1, aabb.y1, aabb.z0) ) continue;
    if ( pointInPlane(p, aabb.x0, aabb.y0, aabb.z1) ) continue;
    if ( pointInPlane(p, aabb.x1, aabb.y0, aabb.z1) ) continue;
    if ( pointInPlane(p, aabb.x0, aabb.y1, aabb.z1) ) continue;
    if ( pointInPlane(p, aabb.x1, aabb.y1, aabb.z1) ) continue;
    return false;
  }
  return true;
}

// ---------------- LevelRenderer ----------------
LevelRenderer::LevelRenderer(Level& lvl)
  : level(lvl), chunks(), xChunks(lvl.width / 16), yChunks(lvl.depth / 16), zChunks(lvl.height / 16), t() {

  level.addListener(this);
  chunks.resize(xChunks * yChunks * zChunks, 0);

  for (int x = 0; x < xChunks; ++x) {
    for (int y = 0; y < yChunks; ++y) {
      for (int z = 0; z < zChunks; ++z) {
        int x0 = x * 16;
        int y0 = y * 16;
        int z0 = z * 16;
        int x1 = (x + 1) * 16; if (x1 > level.width) x1 = level.width;
        int y1 = (y + 1) * 16; if (y1 > level.depth) y1 = level.depth;
        int z1 = (z + 1) * 16; if (z1 > level.height) z1 = level.height;

        chunks[(x + y * xChunks) * zChunks + z] = new Chunk(level, x0, y0, z0, x1, y1, z1);
      }
    }
  }
}

LevelRenderer::~LevelRenderer() {
  level.removeListener(this);
  for (size_t i = 0; i < chunks.size(); ++i) delete chunks[i];
  chunks.clear();
}

void LevelRenderer::render(Player&, int layer) {
  Chunk::rebuiltThisFrame = 0;
  Frustum& fr = Frustum::getFrustum();
  for (size_t i = 0; i < chunks.size(); ++i) {
    if (fr.cubeInFrustum(chunks[i]->aabb)) chunks[i]->render(layer);
  }
}

void LevelRenderer::pick(Player& player) {
  float r = 3.0f;
  AABB box = player.bb.grow(r, r, r);
  int x0 = (int)box.x0;
  int x1 = (int)(box.x1 + 1.0f);
  int y0 = (int)box.y0;
  int y1 = (int)(box.y1 + 1.0f);
  int z0 = (int)box.z0;
  int z1 = (int)(box.z1 + 1.0f);

  glInitNames();
  for (int x = x0; x < x1; ++x) {
    glPushName((GLuint)x);
    for (int y = y0; y < y1; ++y) {
      glPushName((GLuint)y);
      for (int z = z0; z < z1; ++z) {
        glPushName((GLuint)z);
        if (level.isSolidTile(x, y, z)) {
          glPushName(0);
          for (int i = 0; i < 6; ++i) {
            glPushName((GLuint)i);
            t.init();
            Tile::rock.renderFace(t, x, y, z, i);
            t.flush();
            glPopName();
          }
          glPopName();
        }
        glPopName();
      }
      glPopName();
    }
    glPopName();
  }
}

void LevelRenderer::renderHit(const HitResult& h) {
  glEnable(GL_BLEND);
  glBlendFunc(GL_SRC_ALPHA, GL_ONE);
  float alpha = (float)std::sin((double)GetTickCount() / 100.0) * 0.2f + 0.4f;
  glColor4f(1.0f, 1.0f, 1.0f, alpha);
  t.init();
  Tile::rock.renderFace(t, h.x, h.y, h.z, h.f);
  t.flush();
  glDisable(GL_BLEND);
}

void LevelRenderer::setDirty(int x0, int y0, int z0, int x1, int y1, int z1) {
  x0 /= 16; x1 /= 16;
  y0 /= 16; y1 /= 16;
  z0 /= 16; z1 /= 16;
  if (x0 < 0) x0 = 0;
  if (y0 < 0) y0 = 0;
  if (z0 < 0) z0 = 0;
  if (x1 >= xChunks) x1 = xChunks - 1;
  if (y1 >= yChunks) y1 = yChunks - 1;
  if (z1 >= zChunks) z1 = zChunks - 1;

  for (int x = x0; x <= x1; ++x) {
    for (int y = y0; y <= y1; ++y) {
      for (int z = z0; z <= z1; ++z) {
        chunks[(x + y * xChunks) * zChunks + z]->setDirty();
      }
    }
  }
}

void LevelRenderer::tileChanged(int x, int y, int z) { setDirty(x - 1, y - 1, z - 1, x + 1, y + 1, z + 1); }
void LevelRenderer::lightColumnChanged(int x, int z, int y0, int y1) { setDirty(x - 1, y0 - 1, z - 1, x + 1, y1 + 1, z + 1); }
void LevelRenderer::allChanged() { setDirty(0, 0, 0, level.width, level.depth, level.height); }

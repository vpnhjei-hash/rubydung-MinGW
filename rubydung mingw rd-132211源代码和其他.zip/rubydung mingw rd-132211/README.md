# RubyDung（rd-132211）原生移植版

本工程把你提供的 **Java/LWJGL 版 RubyDung** 按原逻辑重写为 **Win32 + OpenGL** 的原生 C++03 程序，目标编译环境：**Windows 2000/XP + MinGW 5.1.2 (GCC 3.4.5)**。

## 目录结构

- `src/`：游戏逻辑与 Win32/OpenGL 平台层
- `third_party/`：
  - `lodepng.*`：PNG 解码（用于读取 `terrain.png`）
  - `miniz*`：deflate/CRC（用于读写 `level.dat` 的 gzip 格式）
- `terrain.png`：纹理图（必须与 exe 同目录）
- `Makefile`：MinGW 下 `mingw32-make` 用
- `build.bat`：一键编译脚本

## 编译（Windows 2000/XP + MinGW）

1. 安装 **MinGW 5.1.2 (GCC 3.4.5)**，确保有 `mingw32-make.exe`。
2. 打开 MinGW 的命令行（或 MSYS）。
3. 进入本工程目录，执行：

- 方法 A：
  - 双击 `build.bat`

- 方法 B：
  - `mingw32-make`

成功后会生成：`rubydung.exe`

## 运行

确保 `rubydung.exe` 与 `terrain.png` 在同一目录，然后双击运行。

首次运行会在当前目录生成/使用 `level.dat`（gzip 格式），用于保存世界。

## 操作

- 鼠标移动：视角
- 左键：在准星命中的方块相邻面 **放置** 方块
- 右键：**破坏** 方块
- 空格：跳跃（落地可跳）
- WASD / 方向键：移动
- R：随机重置位置
- Enter：保存（也会在退出时保存）
- ESC：退出

## 说明（兼容性/差异）

- 渲染路径保持原版思路：Chunk 的两层 Display List + 旧式固定管线 + OpenGL Selection picking。
- `level.dat`：优先按 gzip 读写（与 Java 版一致）。如果读 gzip 失败，会尝试按“纯原始块数组”读取（用于容错）。

## 第三方代码许可

- lodepng：zlib license
- miniz：MIT / public domain 风格许可（见源码头部注释）

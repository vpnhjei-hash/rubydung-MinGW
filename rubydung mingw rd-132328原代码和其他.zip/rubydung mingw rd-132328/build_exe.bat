@echo off
setlocal ENABLEEXTENSIONS

rem ==========================================================
rem RubyDung (native) - one-shot build to EXE (no make needed)
rem Target: Windows 2000/XP + MinGW 5.1.2 (GCC 3.4.5)
rem ==========================================================

cd /d %~dp0

echo [1/4] Checking compiler...

echo [2/4] Creating build directories...
if not exist build mkdir build

echo [3/4] Compiling...
set CXX=g++
set CXXFLAGS=-O2 -Wall -Ithird_party -Isrc

rem Compile C/C++ to objects
%CXX% %CXXFLAGS% -c src\main.cpp -o build\main.o
if errorlevel 1 goto :err
%CXX% %CXXFLAGS% -c src\rubydung.cpp -o build\rubydung.o
if errorlevel 1 goto :err
%CXX% %CXXFLAGS% -c src\win32_gl_app.cpp -o build\win32_gl_app.o
if errorlevel 1 goto :err
%CXX% %CXXFLAGS% -c third_party\lodepng.cpp -o build\lodepng.o
if errorlevel 1 goto :err

rem miniz is C, still compile with g++ for simplicity/compat
%CXX% %CXXFLAGS% -c third_party\miniz.c -o build\miniz.o
if errorlevel 1 goto :err
%CXX% %CXXFLAGS% -c third_party\miniz_tdef.c -o build\miniz_tdef.o
if errorlevel 1 goto :err
%CXX% %CXXFLAGS% -c third_party\miniz_tinfl.c -o build\miniz_tinfl.o
if errorlevel 1 goto :err

echo [4/4] Linking rubydung.exe...
set LIBS=-lopengl32 -lglu32 -lgdi32 -luser32 -lkernel32
%CXX% -mwindows -o rubydung.exe ^
  build\main.o ^
  build\rubydung.o ^
  build\win32_gl_app.o ^
  build\lodepng.o ^
  build\miniz.o ^
  build\miniz_tdef.o ^
  build\miniz_tinfl.o ^
  res.o ^
  %LIBS%
if errorlevel 1 goto :err

echo.
echo SUCCESS: rubydung.exe generated.
echo NOTE: Keep terrain.png in the same folder as rubydung.exe
echo.
exit /b 0

:err
echo.
echo Build failed.
echo If you see missing headers like GL\gl.h, please ensure MinGW include path is correct.
echo.
exit /b 1

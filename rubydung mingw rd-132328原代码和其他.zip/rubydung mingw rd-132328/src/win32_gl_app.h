// RubyDung native port (Win2k/XP + MinGW GCC 3.4.5)
// C++03, Win32 + OpenGL 1.1 + GLU
#pragma once

#include <windows.h>
#include <vector>

struct MouseEvent {
  int button;   // 0 left, 1 right
  bool down;
};

struct InputState {
  int mouseDX;
  int mouseDY;
  bool mouseButtons[2];
  std::vector<MouseEvent> mouseEvents; // edge events since last frame

  bool keyEsc;
  bool keyReset; // R
  bool keyUp;
  bool keyDown;
  bool keyLeft;
  bool keyRight;
  bool keyJump;
};

class Win32GLApp {
public:
  Win32GLApp();
  ~Win32GLApp();

  bool create(const char* title, int w, int h, bool fullscreen);
  void destroy();

  // If create() fails, returns a human-readable reason.
  const char* lastErrorText() const { return m_lastErrorText; }

  bool pumpEvents();            // returns false if should quit
  void beginFrame();            // updates mouse deltas + clears edge events
  void endFrame();              // swap buffers

  int width() const { return m_w; }
  int height() const { return m_h; }
  HDC hdc() const { return m_hdc; }

  const InputState& input() const { return m_input; }
  InputState& inputMutable() { return m_input; }

private:
  static LRESULT CALLBACK WndProcThunk(HWND hWnd, UINT msg, WPARAM wParam, LPARAM lParam);
  LRESULT wndProc(HWND hWnd, UINT msg, WPARAM wParam, LPARAM lParam);

  void updateKeyboard();
  void updateMouseDelta();

  HWND m_hwnd;
  HDC m_hdc;
  HGLRC m_glrc;
  int m_w;
  int m_h;
  bool m_fullscreen;

  POINT m_lastCursor;
  bool m_cursorInit;
  InputState m_input;
  char m_lastErrorText[512];

  void setLastError(const char* where);
};

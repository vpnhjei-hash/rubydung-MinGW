#include "win32_gl_app.h"
#include "rubydung.h"

#include <cstdio>
#include <cstdlib>
#include <vector>

#include <GL/gl.h>
#include <GL/glu.h>

static void checkError() {
  GLenum e = glGetError();
  if (e != GL_NO_ERROR) {
    const GLubyte* s = gluErrorString(e);
    std::fprintf(stderr, "OpenGL error: %s (%u)\n", s ? (const char*)s : "?", (unsigned)e);
    std::exit(1);
  }
}

static void setupCamera(Player& player, float a, int w, int h) {
  glMatrixMode(GL_PROJECTION);
  glLoadIdentity();
  gluPerspective(70.0, (double)w / (double)h, 0.05, 1000.0);

  glMatrixMode(GL_MODELVIEW);
  glLoadIdentity();

  // moveCameraToPlayer
  glTranslatef(0.0f, 0.0f, -0.3f);
  glRotatef(player.xRot, 1.0f, 0.0f, 0.0f);
  glRotatef(player.yRot, 0.0f, 1.0f, 0.0f);

  float x = player.xo + (player.x - player.xo) * a;
  float y = player.yo + (player.y - player.yo) * a;
  float z = player.zo + (player.z - player.zo) * a;
  glTranslatef(-x, -y, -z);
}

static void setupPickCamera(Player& player, float a, int w, int h, int x, int y) {
  glMatrixMode(GL_PROJECTION);
  glLoadIdentity();

  GLint viewport[16];
  glGetIntegerv(GL_VIEWPORT, viewport);
  gluPickMatrix((GLdouble)x, (GLdouble)y, 5.0, 5.0, viewport);
  gluPerspective(70.0, (double)w / (double)h, 0.05, 1000.0);

  glMatrixMode(GL_MODELVIEW);
  glLoadIdentity();

  // moveCameraToPlayer
  glTranslatef(0.0f, 0.0f, -0.3f);
  glRotatef(player.xRot, 1.0f, 0.0f, 0.0f);
  glRotatef(player.yRot, 0.0f, 1.0f, 0.0f);
  float px = player.xo + (player.x - player.xo) * a;
  float py = player.yo + (player.y - player.yo) * a;
  float pz = player.zo + (player.z - player.zo) * a;
  glTranslatef(-px, -py, -pz);
}

static bool pick(LevelRenderer& renderer, Player& player, float a, int w, int h, HitResult& outHit) {
  std::vector<GLuint> selectBuf(2000);
  glSelectBuffer((GLsizei)selectBuf.size(), &selectBuf[0]);
  glRenderMode(GL_SELECT);

  setupPickCamera(player, a, w, h, w / 2, h / 2);

  renderer.pick(player);

  GLint hits = glRenderMode(GL_RENDER);

  if (hits <= 0) return false;

  // Parse hits like Java implementation
  const GLuint* p = &selectBuf[0];
  GLuint closest = 0;
  int hitNameCount = 0;
  GLuint names[10];

  for (int i = 0; i < hits; ++i) {
    GLuint nameCount = *p++;
    GLuint minZ = *p++;
    (void)*p++; // maxZ

    if ((i == 0) || (minZ < closest)) {
      closest = minZ;
      hitNameCount = (int)nameCount;
      for (GLuint j = 0; j < nameCount && j < 10; ++j) names[j] = *p++;
      // skip remaining names if any
      for (GLuint j = (nameCount < 10 ? nameCount : 10); j < nameCount; ++j) (void)*p++;
    } else {
      for (GLuint j = 0; j < nameCount; ++j) (void)*p++;
    }
  }

  if (hitNameCount > 0) {
    // names: x, y, z, 0, face
    outHit = HitResult((int)names[0], (int)names[1], (int)names[2], (int)names[3], (int)names[4]);
    return true;
  }
  return false;
}

int WINAPI WinMain(HINSTANCE, HINSTANCE, LPSTR, int) {
  std::srand(0xC0FFEE);

  Win32GLApp app;
  if (!app.create("RubyDung (rd-132328 native MinGW port)", 1024, 768, false)) {
    MessageBoxA(NULL, app.lastErrorText()[0] ? app.lastErrorText() : "Failed to create window/OpenGL context", "RubyDung", MB_ICONERROR);
    return 0;
  }

  // GL init (match Java)
  glEnable(GL_TEXTURE_2D);
  glShadeModel(GL_SMOOTH);
  glClearColor(0.5f, 0.8f, 1.0f, 0.0f);
  glClearDepth(1.0);
  glEnable(GL_DEPTH_TEST);
  glDepthFunc(GL_LEQUAL);

  // game objects
  Level level(256, 256, 64);
  LevelRenderer levelRenderer(level);
  Player player(level);
  std::vector<Zombie*> zombies;
  zombies.reserve(100);
  for (int i = 0; i < 100; ++i) zombies.push_back(new Zombie(level, 128.0f, 50.0f, 128.0f));
  Timer timer(60.0f);

  float fogColor[4];
  int col = 920330;
  fogColor[0] = (float)((col >> 16) & 0xFF) / 255.0f;
  fogColor[1] = (float)((col >> 8) & 0xFF) / 255.0f;
  fogColor[2] = (float)((col) & 0xFF) / 255.0f;
  fogColor[3] = 1.0f;

  bool running = true;
  unsigned long lastTime = GetTickCount();
  int frames = 0;
  bool lastEnter = false;

  while (running) {
    if (!app.pumpEvents()) break;

    app.beginFrame();
    const InputState& in = app.input();

    if (in.keyEsc) break;

    timer.advanceTime();
    for (int i = 0; i < timer.ticks; ++i) {
      for (size_t zi = 0; zi < zombies.size(); ++zi) zombies[zi]->tick();
      player.tick(in.keyReset, in.keyUp, in.keyDown, in.keyLeft, in.keyRight, in.keyJump);
    }

    // mouse look (invert Y to match typical FPS feel)
    player.turn((float)in.mouseDX, (float)-in.mouseDY);

    // picking
    HitResult hit;
    bool hasHit = pick(levelRenderer, player, timer.a, app.width(), app.height(), hit);

    // mouse buttons events -> break/place
    for (size_t i = 0; i < in.mouseEvents.size(); ++i) {
      const MouseEvent& ev = in.mouseEvents[i];
      if (!ev.down) continue;
      if (!hasHit) continue;

      if (ev.button == 1) {
        // right click destroy
        level.setTile(hit.x, hit.y, hit.z, 0);
      } else if (ev.button == 0) {
        // left click place adjacent
        int x = hit.x;
        int y = hit.y;
        int z = hit.z;
        if (hit.f == 0) --y;
        if (hit.f == 1) ++y;
        if (hit.f == 2) --z;
        if (hit.f == 3) ++z;
        if (hit.f == 4) --x;
        if (hit.f == 5) ++x;
        level.setTile(x, y, z, 1);
      }
    }

    // consume mouse edge events
    app.inputMutable().mouseEvents.clear();

    // save on Enter (edge)
    bool enterNow = (GetAsyncKeyState(VK_RETURN) & 0x8000) != 0;
    if (enterNow && !lastEnter) level.save();
    lastEnter = enterNow;

    // render
    glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);
    setupCamera(player, timer.a, app.width(), app.height());

    glEnable(GL_CULL_FACE);

    glEnable(GL_FOG);
    glFogi(GL_FOG_MODE, GL_EXP);
    glFogf(GL_FOG_DENSITY, 0.2f);
    glFogfv(GL_FOG_COLOR, fogColor);

    glDisable(GL_FOG);
    levelRenderer.render(player, 0);
    for (size_t zi = 0; zi < zombies.size(); ++zi) zombies[zi]->render(timer.a);

    glEnable(GL_FOG);
    levelRenderer.render(player, 1);

    glDisable(GL_TEXTURE_2D);
    if (hasHit) levelRenderer.renderHit(hit);
    glDisable(GL_FOG);

    glEnable(GL_TEXTURE_2D);

    app.endFrame();

    ++frames;
    while (GetTickCount() >= lastTime + 1000) {
      std::printf("%d fps, %d\n", frames, Chunk::updates);
      Chunk::updates = 0;
      lastTime += 1000;
      frames = 0;
    }

    checkError();
  }

  level.save();
  for (size_t zi = 0; zi < zombies.size(); ++zi) delete zombies[zi];
  app.destroy();
  return 0;
}


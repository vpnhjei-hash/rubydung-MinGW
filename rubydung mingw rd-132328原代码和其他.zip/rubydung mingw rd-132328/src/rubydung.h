#pragma once

#include <vector>
#include <string>
#include <map>

struct AABB {
  float x0, y0, z0;
  float x1, y1, z1;
  float epsilon;

  AABB() : x0(0), y0(0), z0(0), x1(0), y1(0), z1(0), epsilon(0.0f) {}
  AABB(float _x0, float _y0, float _z0, float _x1, float _y1, float _z1)
    : x0(_x0), y0(_y0), z0(_z0), x1(_x1), y1(_y1), z1(_z1), epsilon(0.0f) {}

  AABB expand(float xa, float ya, float za) const;
  AABB grow(float xa, float ya, float za) const;

  float clipXCollide(const AABB& c, float xa) const;
  float clipYCollide(const AABB& c, float ya) const;
  float clipZCollide(const AABB& c, float za) const;

  bool intersects(const AABB& c) const;
  void move(float xa, float ya, float za);
};

struct HitResult {
  int x, y, z;
  int t;
  int f;
  HitResult() : x(0), y(0), z(0), t(0), f(0) {}
  HitResult(int _x, int _y, int _z, int _t, int _f) : x(_x), y(_y), z(_z), t(_t), f(_f) {}
};

class Timer {
public:
  Timer(float ticksPerSecond);
  void advanceTime();

  int ticks;
  float a;
  float timeScale;
  float fps;

public:
  // 高精度计时（供动画/统计使用）
  static long long nanoTime();

private:
  static const long long NS_PER_SECOND = 1000000000LL;
  float ticksPerSecond;
  long long lastTime;
  float passedTime;
};

class LevelListener {
public:
  virtual ~LevelListener() {}
  virtual void tileChanged(int x, int y, int z) = 0;
  virtual void lightColumnChanged(int x, int z, int y0, int y1) = 0;
  virtual void allChanged() = 0;
};

class Level {
public:
  const int width;
  const int height;
  const int depth;

  Level(int w, int h, int d);
  void load();
  void save();

  void addListener(LevelListener* l);
  void removeListener(LevelListener* l);

  bool isTile(int x, int y, int z) const;
  bool isSolidTile(int x, int y, int z) const;
  bool isLightBlocker(int x, int y, int z) const;

  std::vector<AABB> getCubes(const AABB& aabb) const;
  float getBrightness(int x, int y, int z) const;

  void setTile(int x, int y, int z, int type);

private:
  std::vector<unsigned char> blocks;
  std::vector<int> lightDepths;
  std::vector<LevelListener*> listeners;

  void calcLightDepths(int x0, int y0, int x1, int y1);
  int index(int x, int y, int z) const { return (y * height + z) * width + x; }
};

class Tesselator {
public:
  Tesselator();
  void init();
  void tex(float u, float v);
  void color(float r, float g, float b);
  void vertex(float x, float y, float z);
  void flush();

private:
  enum { MAX_VERTICES = 100000 };
  std::vector<float> vtx;   // 3 * n
  std::vector<float> texc;  // 2 * n
  std::vector<float> col;   // 3 * n
  int vertices;
  float u, v;
  float r, g, b;
  bool hasColor;
  bool hasTexture;

  void clear();
};

class Tile {
public:
  static Tile rock;
  static Tile grass;

  void render(Tesselator& t, const Level& level, int layer, int x, int y, int z) const;
  void renderFace(Tesselator& t, int x, int y, int z, int face) const;

private:
  int tex;
  explicit Tile(int t);
};

class Textures {
public:
  // mode: GL_NEAREST / GL_LINEAR ...
  static int loadTexture(const std::string& filename, int mode);
  static void bind(int id);

private:
  static int lastId;
  static std::map<std::string, int> idMap;
};

class Chunk {
public:
  AABB aabb;
  Level& level;
  int x0, y0, z0;
  int x1, y1, z1;

  Chunk(Level& level, int x0, int y0, int z0, int x1, int y1, int z1);
  void render(int layer);
  void setDirty();

  static int rebuiltThisFrame;
  static int updates;

private:
  bool dirty;
  int lists;

  static int texture;
  static Tesselator t;

  void rebuild(int layer);
};

class Player {
public:
  Player(Level& level);

  float xo, yo, zo;
  float x, y, z;
  float xd, yd, zd;
  float yRot, xRot;
  AABB bb;
  bool onGround;

  void turn(float xo, float yo);
  void tick(bool keyReset, bool keyUp, bool keyDown, bool keyLeft, bool keyRight, bool keyJump);

private:
  Level& level;
  void resetPos();
  void setPos(float x, float y, float z);
  void move(float xa, float ya, float za);
  void moveRelative(float xa, float za, float speed);
};

// ---------------- Character model (rd-132328) ----------------
struct Vec3 {
  float x, y, z;
  Vec3() : x(0), y(0), z(0) {}
  Vec3(float _x, float _y, float _z) : x(_x), y(_y), z(_z) {}
};

struct Vertex {
  Vec3 pos;
  float u, v;
  Vertex() : pos(), u(0), v(0) {}
  Vertex(float x, float y, float z, float _u, float _v) : pos(x, y, z), u(_u), v(_v) {}
};

struct RDPolygon {
  Vertex vertices[4];
  RDPolygon();
  RDPolygon(const Vertex* v4);
  RDPolygon(const Vertex* v4, int u0, int v0, int u1, int v1);
  void render() const;
};

class Cube {
public:
  Cube(int xTexOffs, int yTexOffs);
  void setTexOffs(int xTexOffs, int yTexOffs);
  void addBox(float x0, float y0, float z0, int w, int h, int d);
  void setPos(float x, float y, float z);
  void render() const;

  float x, y, z;
  float xRot, yRot, zRot;

private:
  Vertex verts[8];
  RDPolygon polys[6];
  int xTexOffs;
  int yTexOffs;
  bool hasBox;
};

class Zombie {
public:
  Zombie(Level& level, float x, float y, float z);
  void tick();
  void render(float a);

  // entity fields
  float xo, yo, zo;
  float x, y, z;
  float xd, yd, zd;
  float yRot, xRot;
  AABB bb;
  bool onGround;

private:
  Level* level;
  float heightOffset;

  // model parts
  Cube head, body, arm0, arm1, leg0, leg1;
  float rot;
  float timeOffs;
  float speed;
  float rotA;

  void resetPos();
  void setPos(float x, float y, float z);
  void move(float xa, float ya, float za);
  void moveRelative(float xa, float za, float speed);
};

class Frustum {
public:
  static Frustum& getFrustum();
  bool cubeInFrustum(const AABB& aabb) const;

private:
  float frustum[6][4];
  Frustum();
  void calculateFrustum();
};

class LevelRenderer : public LevelListener {
public:
  LevelRenderer(Level& level);
  ~LevelRenderer();
  void render(Player& player, int layer);
  void pick(Player& player);
  void renderHit(const HitResult& h);

  virtual void tileChanged(int x, int y, int z);
  virtual void lightColumnChanged(int x, int z, int y0, int y1);
  virtual void allChanged();

private:
  enum { CHUNK_SIZE = 16 };
  Level& level;
  std::vector<Chunk*> chunks;
  int xChunks, yChunks, zChunks;
  Tesselator t;

  void setDirty(int x0, int y0, int z0, int x1, int y1, int z1);
};

#pragma once

// Minimal export definitions for single-file use.
// In this project we build everything statically with MinGW, so no dllimport/dllexport needed.

#ifndef MINIZ_EXPORT
#define MINIZ_EXPORT
#endif

@echo off
setlocal

rem 需要：MinGW 5.1.2 (GCC 3.4.5) + mingw32-make

cd /d %~dp0

echo Building...
mingw32-make clean
if errorlevel 1 goto :err
mingw32-make
if errorlevel 1 goto :err

echo Done. Run: rubydung.exe
exit /b 0

:err
echo Build failed.
exit /b 1
